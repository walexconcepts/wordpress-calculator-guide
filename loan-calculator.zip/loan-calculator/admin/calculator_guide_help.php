<?php
	
?>
<div style="float:none" class="well-3 center-block-3 col-md-4-3">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>
Thank you for installing Advanced Calculator Loan Calculator. This plugin is a plan or arrange (an event) to how much you'd pay monthly, Bi-weekly or weekly on mortgage, car finance and so on at a 
particular time. Please visit [demo](https://walexconcepts.com/wordpress/plugin-demo/).
</p>


Free Version features:
<p>
<ul>
<li>* Calculator Guide looks responsive on any device.</li>
<li>* You can use it as simple calculator with Loan amount, Down payment, Loan length, Annual Interest and Payment term.</li>
<li>* The calculator display results in block or Popup window with simple text.</li>
<li>* Use shortcode to add it to any page at backend or frontend.</li>
<li>* Click 'Settings' under 'calculator_guild' menu at admin page to select your option for display result.</li>
<li>* Loan length based on years.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of te above free version features. </li>
<li>* The calculator display results in modal Popup window with simple table.</li>
<li>* Click 'Settings' under 'calculator_guild' menu at admin page to select Modal Popup option for display result.</li>
<li>* Click 'Show Payment schedule' to display plan or arrangement for payment.</li>
<li>* Loan length based on Months.</li>
</ul>
</p>
</div>