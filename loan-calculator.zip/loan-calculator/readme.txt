===Calculator Guide===
Contributors: Awodeyi Adewale Emmanuel
Donate link: https://izzumes.com/ 
Tags: mortgage calculator, loan, mortgage, wordpress mortgage calculator, bi-weekly, weekly, car finance
Requires at least: 5.4
Tested up to: 6.1.1
Stable tag: 3.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is a plan or arrange (an event) to how much you'd pay monthly, Bi-weekly or weekly on mortgage, car finance and so on at a particular time.

== Description ==
<p>
This plugin is a plan or arrange (an event) to how much you'd pay monthly, Bi-weekly or weekly on mortgage, car finance and so on at a particular time. Please
visit [demo](https://walexconcepts.com/wordpress/plugin-demo/).
</p>

Free Version features:
<p>
<ul>
<li>* Calculator Guide looks responsive on any device.</li>
<li>* You can use it as simple calculator with Loan amount, Down payment, Loan length, Annual Interest and Payment term.</li>
<li>* The calculator display results in block or Popup window with simple text.</li>
<li>* Use shortcode to add it to any page at backend or frontend.</li>
<li>* Click 'Settings' under 'calculator_guild' menu at admin page to select your option for display result.</li>
<li>* Loan length based on years.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of te above free version features. </li>
<li>* The calculator display results in modal Popup window with simple table.</li>
<li>* Click 'Settings' under 'calculator_guild' menu at admin page to select Modal Popup option for display result.</li>
<li>* Click 'Show Payment schedule' to display plan or arrangement for payment.</li>
<li>* Loan length based on Months.</li>
</ul>
</p>

== Installation ==
<p>
<ul>
<li>1. Upload files of calculator_guide to the `/wp-content/plugins/`</li> 
<li>2. Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>3. At backend or admin page, put ShortCode /*[calculator-guide]*/ to add calculator to the page. Please always remember 
to remove [/* */] from the Shortcode.</li>
<li>4. At frontend, put ShortCode /*if ( shortcode_exists( 'calculator-guide' ) ) { echo do_shortcode('[calculator-guide]');} */ to 
add calculator to the page. Please always remember to remove [/* */] from the Shortcode.</li>
<li>5. At backend , click 'Settings' under 'calculator_guild' menu in WordPress to display caculator guide admin page.</li>
<li>6. At backend , click 'Help' under 'calculator_guild' menu in WordPress for help user guide.</li>
</ul>
</p>

== Frequently Asked Questions ==

= Does Calculator Guide work with any Wordpress theme? =
Yes, it does. You can use it with any Wordpress theme.

= Do I get free support for this free plugin? = 
Yes, we can provide support via email and chat if needed.

== Screenshots ==
<p>
<ul>
<li>1. Calculator Guild admin page or back-end</li>
<li>2. Front-end</li>
<li>3. Alert Result with text</li>
<li>4. Block Results with text</li>
<li>5. Modal Popup Results with text and table</li>
<li>6. Responsive layout mobile</li>
<li>7. Responsive layout tablet</li> 
<li>8. Responsive layout Modal Popup</li> 
</ul>
</p>

== Changelog ==
<p>
<ul>
= 1.0 =
<li>* roll out March, 14, 2022)</li>
</ul>
</p>
